// Register Service Worker for PWA support
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('../sw.js')
      .then(reg => console.log('Service Worker registriert:', reg.scope))
      .catch(err => console.error('Service Worker Fehler:', err));
  });
}

// Search & Filter Event Handling
document.getElementById('heightFilter').addEventListener('change', applyFilters);
document.getElementById('typeFilter').addEventListener('change', applyFilters);

function applyFilters() {
  const selectedHeight = parseFloat(document.getElementById('heightFilter').value);
  const selectedType = document.getElementById('typeFilter').value;

  const filtered = poolsData.filter(pool => {
    const heightMatch = selectedHeight === 0 || pool.maxJump >= selectedHeight;
    const typeMatch = selectedType === 'all' || pool.type === selectedType;
    return heightMatch && typeMatch;
  });

  renderMarkers(filtered);
}

// Geolocation Handling
document.getElementById('locateBtn').addEventListener('click', () => {
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(pos => {
      const lat = pos.coords.latitude;
      const lng = pos.coords.longitude;
      map.setView([lat, lng], 12);
    }, () => {
      alert('Standort konnte nicht ermittelt werden.');
    });
  }
});
